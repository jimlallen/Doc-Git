select * from
(select USERID, count(ROLEID) as number_of_profiles
from CIADB01.ROLEXREF
where SYSID = 'CPU6'
group by USERID
order by number_of_profiles desc) y
where y.number_of_profiles > 150;